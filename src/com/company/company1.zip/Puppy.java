package com.company;

import com.company.Dog;

public class Puppy extends Dog {
    public void weep(){
        System.out.println("weeping...");
    }
}
